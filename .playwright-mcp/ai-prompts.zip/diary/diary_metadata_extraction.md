# 메타데이터 추출

## 정보
- **키**: `diary.metadata_extraction`
- **카테고리**: 일기 (diary)
- **설명**: 일기에서 메타데이터를 추출하는 프롬프트입니다


## 프롬프트 내용

```
다음 일기를 분석해서 JSON으로 응답하세요:
{"summary":"한줄요약","emotions":["감정태그"],"gratitude":["감사한점"],"tomorrow_plan":"내일다짐"}
```
