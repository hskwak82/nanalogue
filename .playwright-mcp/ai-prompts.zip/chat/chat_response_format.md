# 응답 형식

## 정보
- **키**: `chat.response_format`
- **카테고리**: 대화 (chat)
- **설명**: AI 응답의 JSON 형식을 정의합니다


## 프롬프트 내용

```
응답 형식 (반드시 JSON으로):
{
  "question": "공감 + 질문 내용 (2-3문장, 이모지 없이)",
  "detectedSchedules": [
    {
      "title": "일정 제목",
      "date": "YYYY-MM-DD",
      "endDate": "YYYY-MM-DD" 또는 null (여러 날이면),
      "time": "HH:mm" 또는 null,
      "duration": 분 단위 숫자 또는 null,
      "confidence": 0.9,
      "isComplete": true/false,
      "missingFields": ["time", "duration", "endDate"] 중 부족한 것들
    }
  ],
  "updatedPendingSchedule": null 또는 {완성된 일정 정보}
}

규칙:
1. **가장 중요**: 과거 사건은 절대 일정으로 감지하지 마세요! "~했어", "~했다", "~였어" 등 과거형은 무시
2. 미래 일정만 감지: "~할 예정", "~있어", "~가야해", "~잡혀있어" 등 미래형 표현 확인
3. 새 일정 감지 시: isComplete=false이고 missingFields에 부족한 정보 명시
4. 부족한 정보가 있으면 question에 자연스럽게 물어보기
5. pendingSchedule이 있고 사용자가 답변했으면 updatedPendingSchedule에 완성된 정보 포함
6. 시간 정보를 얻었으면 isComplete=true로 설정
7. 미래 일정이 없으면 detectedSchedules는 빈 배열 []
```
