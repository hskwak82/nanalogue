# AI 프롬프트 내보내기

내보내기 일시: 2025. 12. 27. 오후 5:56:56

## 파일 구조
- `metadata.json`: 가져오기용 메타데이터
- `chat/`: 대화 관련 프롬프트
- `diary/`: 일기 관련 프롬프트
- `schedule/`: 일정 관련 프롬프트

## 프롬프트 목록
- `chat.closing`: 종료 메시지
- `chat.greeting`: 첫 인사말
- `chat.personality`: AI 성격 정의
- `chat.phase_early`: 초반 대화 가이드
- `chat.phase_late`: 후반 대화 가이드
- `chat.phase_mid`: 중반 대화 가이드
- `chat.response_format`: 응답 형식
- `chat.schedule_detection`: 일정 감지 규칙
- `diary.metadata_extraction`: 메타데이터 추출
- `diary.write_style`: 일기 작성 스타일
- `schedule.parsing`: 일정 파싱 프롬프트

## 가져오기 방법
1. MD 파일 수정
2. 수정한 파일들을 다시 ZIP으로 압축
3. 관리자 페이지에서 가져오기
